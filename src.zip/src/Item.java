import java.util.ArrayList;

public class Item {
    public static class SubItem{
        public Item item;
        public String title;
        public int price;
        SubItem(Item item, String title, int price) {
            this.item = item;
            this.title = title;
            this.price = price;
        }
    }
    public String title;
    public ArrayList<SubItem> packages;
}
