import java.util.ArrayList;

public class Order {
    public static class OrderItem{
        public Item.SubItem item;
        public int cnt;
    }
    public int orderId;
    private Customer customer;
    private ArrayList<OrderItem> itemList;
}
