public class Customer {
    public int customerId;
    private Contact contact;
    private String address;
}
