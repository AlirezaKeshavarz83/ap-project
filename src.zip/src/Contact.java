public class Contact {
    public String name;
    private String phoneNumber;
    private String emailAddress;
}
